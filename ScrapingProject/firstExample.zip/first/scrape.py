import requests
from bs4 import BeautifulSoup

ROOT = 'https://www.bger.ch'
URL = 'https://www.bger.ch/index/press/press-inherit-template/press-mitteilungen.htm'
response = requests.get(URL)
content = BeautifulSoup(response.text, 'lxml')

# extract URLs
urls = content.find_all('a')

# filter for 'href' attribute and '.pdf' in URL
for url in urls:
    try:
        if '.pdf' in url['href']:
            pdf_url = ROOT + url['href']
            pdf_res = requests.get(pdf_url)
            filename = pdf_url.split('/')[-1]
            
            with open('./first/pdf/' + filename, 'wb') as f:
                f.write(pdf_res.content)

    except Exception as e:
        print('Error', e)

